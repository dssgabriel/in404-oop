public class AdresseIP
{
    // Attribute
    private String ip;

    // Constructor
    public AdresseIP(String ip)
    {
        this.ip = ip;
    }

    // Getter
    @Override
    public String toString()
    {
        return this.ip;
    }
}
