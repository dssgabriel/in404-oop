import java.io.*;

public interface Commande 
{
	String execute() throws IOException;
}
